/**
 *
 * @author tugba
 */
public class Dragon extends Beyblade
{
    private String kutsalCanavar;
    private String ozelYetenek;
    public Dragon(String beybladeci, int donusHizi, int saldiriGucu, String kutsalCanavar, String ozelYetenek) 
    {
        super(beybladeci, donusHizi, saldiriGucu);
        
        this.kutsalCanavar = kutsalCanavar;
        this.ozelYetenek = ozelYetenek;
    }

    @Override
    public void bilgileriGoster() 
    {
        super.bilgileriGoster();
        
        System.out.println("Kutsal Canavar Adı: " + kutsalCanavar);
        System.out.println("Özel Yetenek: " + ozelYetenek);
    }

    @Override
    public void kutsalCanavarOrtayaCikar() 
    {
        System.out.println(getBeybladeci() + " " + kutsalCanavar + " ı ortaya çıkarıyor..." );
        System.out.println(getBeybladeci() + " ın Saldırısı: Hayalet Kasırga"); 
    }
    
    
}
